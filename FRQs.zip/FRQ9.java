// import java.util.ArrayList;

public class FRQ9{

    private String title;
    private String author;

    public FRQ9(String t, String a)
    {
      title = t;
      author = a;
    }
    public void printBookInfo()
    {
      System.out.println(title + ", written by " + author);
    }

    public String toString(){
      return title + ", written by " + author;
    }
}
