import java.util.ArrayList;

public class FRQ7 {

// The list of possible user names, based on a user’s first and last names and initialized by the constructor.

  private ArrayList<String> possibleNames;
/** Constructs a UserName object as described in part (a).

* Precondition: firstName and lastName have length greater than 0

* and contain only uppercase and lowercase letters.

*/
  public FRQ7(String firstName, String lastName){ 
  /* to be implemented in part (a) */ 
  possibleNames = new ArrayList<String>();

    for (int i=0; i < firstName.length(); i++){
      possibleNames.add(lastName + firstName.substring(0, i + 1));
    } 
  
  }

 

/** Returns true if arr contains name, and false otherwise. */

public boolean isUsed(String name, String[] arr){ 
  for(String str : arr){
    if(name.equals(str))
      return true;
  } 

  return false;
  }

 

/** Removes strings from possibleNames that are found in usedNames as described in part (b).

*/

public void setAvailableUserNames(String[] usedNames){
  for(String str : usedNames ){
    if(isUsed(str, possibleNames.toArray(new String[possibleNames.size()]))){
      possibleNames.remove(str);
    }

  }
}

public void printPossiableNames(){
  System.out.println(possibleNames.toString());
}

}
