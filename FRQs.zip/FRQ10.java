
public class FRQ10{

  /** Precondition: a and b are positive integers.
  * Returns the greatest common factor of a and b, as described in part (a).
  */
  public static int gcf(int a, int b){
    int gcf = 1;
    int smallNum = a < b ? a : b;
    for(int i = 1; i <= smallNum; i++){
        if( (a%i == 0) && (b%i == 0) ){
            gcf = i;
        }
    }
    return gcf;
  }

  /** Precondition: numerator and denominator are positive integers.
  * Reduces the fraction numerator / denominator
  * and prints the result, as described in part (b).
  */
  public static void reduceFraction(int numerator, int denominator){

    int reduceNumerator = numerator;
    int reduceDemominator = denominator;
    int myGCF = gcf(numerator, denominator );

    if( (numerator%myGCF == 0) && ( denominator % myGCF == 0 )){
      reduceNumerator = reduceNumerator/myGCF;
      reduceDemominator = reduceDemominator/myGCF; 
    }
    System.out.println( numerator + "/" + denominator + " reduces to " + reduceNumerator + "/" + reduceDemominator);
  }


}