import java.util.Scanner;
import java.util.ArrayList;

public class Main {

  public static void main(String[] args) {
     Scanner sc = new Scanner(System.in); 

      System.out.println("                         ");
      System.out.println("|        Ridhima's FRQs   |");
      System.out.println("|        Choose an FRQ:   |");
      System.out.println("                         ");
      System.out.println("|        1 --> FRQ 2     |");
      System.out.println("|        2 --> FRQ 3     |");
      System.out.println("|        3 --> FRQ 4.1   |");
      System.out.println("|        4 --> FRQ 4.2   |");
      System.out.println("|        5 --> FRQ 5.1   |");
      System.out.println("|        6 --> FRQ 5.2   |");
      System.out.println("|        7 --> FRQ 6     |");
      System.out.println("|        8 --> FRQ 7     |");
      System.out.println("|        9 --> FRQ 8     |");
      System.out.println("|       10 --> FRQ 9     |");
      System.out.println("|       11 --> FRQ 10    |");


      
      int option = sc.nextInt();
      sc.nextLine(); // to read newline after interger
      // Switch construct
      switch (option) {
      
        case 1:
          System.out.println("FRQ2 --> Begin");
          System.out.println("Enter a numerical sequence");
          String input = sc.nextLine();
          FRQ2 gradShow = new FRQ2(input);
          gradShow.display();
          System.out.println("Enter a new numerical sequence");
          input = sc.nextLine();
          gradShow.changeSequence(input);
          System.out.println("Enter a segment to be inserted into a sequence");
          String segment = sc.nextLine();
          System.out.println("Enter a index where the above segment is to be inserted into a sequence");
          int index = sc.nextInt();
          sc.nextLine(); // to read newline after interger
          gradShow.insertSegment(segment, index);
          gradShow.display();
          System.out.println("Removing segment 00");
          gradShow.removeSegment("00");
          gradShow.display();
          System.out.println("Removing segment 00");
          gradShow.removeSegment("00");
          gradShow.display();
          System.out.println("Straight Line Distance between two lights 5 , 6");
          double distance = gradShow.straintLineDistance(5, 6);
          System.out.println( "Distance is "+ distance);
          System.out.println("FRQ2 --> End");
          break;

        case 2:
          
          System.out.println("Are you attending (true/false) ?");
          boolean rsvp = sc.nextBoolean();
          System.out.println("Enter food selection between 1 to 9");
          int selection = sc.nextInt();
          sc.nextLine(); // to read newline after interger
          System.out.println("Enter a string for option2 ");
          String option2 = sc.nextLine();
          option2 = sc.nextLine();

          FRQ3 frq3 = new FRQ3(rsvp,selection,"",option2);
          System.out.print("RSVP Info ==> ");
          frq3.printAttending();
          System.out.print("Selcted food ==> ");
          frq3.printFoodSelection();
          System.out.print("Food selection with RSVP info ==> ");
          frq3.storeFoodSelectionWithRSVPInfo();
          System.out.println(frq3.getOption1());
          System.out.print("Comparing options ==> ");
          frq3.compareOptions();
          break;
        
        case 3:
          System.out.println("Enter a string to find a longestStreak ");

          String str = sc.nextLine();
          FRQ4One frq41 = new FRQ4One();
          frq41.longestStreak(str);
          frq41.printInfo();
          sc.close();
          break;

        
        case 4:
          FRQ4 c = new FRQ4(10, 20);
          c.playGame();
          
          break;


        case 5: 
          FRQ5One frq5 = new FRQ5One();
          System.out.print("What is the host name?");
          String hostName = sc.nextLine();
          System.out.print("What is the address");
          String address = sc.nextLine();
          System.out.print("What is the name?");
          String userName = sc.nextLine();
          System.out.print("What is the host age?");
          String userAge = sc.nextLine();
          System.out.print("Who is being invited?");
          String invited = sc.nextLine();
          int age = Integer.parseInt(userAge);
          
          
          frq5.getHostName(hostName); 
          frq5.getAddress(address);
          frq5.getName(userName);
          frq5.getAge(age);
          frq5.setAddress(address);
          frq5.invite(invited, address, hostName);
        
          break;


        case 6: 
          System.out.println("Enter a prefix for passwordgen");
          String prefix = sc.nextLine();
          System.out.println("Enter a random number length for passwordgen");
          int length = sc.nextInt();
          sc.nextLine(); //to read the new line character
          FRQ5Two pwd1 = new FRQ5Two(length);
          FRQ5Two pwd2 = new FRQ5Two(length, prefix);

          System.out.println("Enter the number of times for passwordgen");
          int count = sc.nextInt();
          sc.nextLine(); //to read the new line character
          for(int i = 0; i < count; i++){
            System.out.println("Password: " + pwd1.pwdGen());
            System.out.println("Password: " + pwd2.pwdGen());
          }
          System.out.println("Passwords count: " + FRQ5Two.pwdCount());
        
          break;

      
        case 7:
          FRQ6 FRQ6 = new FRQ6();
          FRQ6.scanItemSold();
          FRQ6.computeWages(10, 1.5);
          FRQ6.printWages();
          break;

        case 8:
          System.out.println("Enter a first name");
          String firstName = sc.nextLine();

          System.out.println("Enter a last name");
          String lastName = sc.nextLine();

          System.out.println("Enter used names seperated by comma(,) ");
          String str1 = sc.nextLine();
          String[] usedNames = str1.split(",");

          FRQ7 username = new FRQ7(firstName, lastName);

          username.setAvailableUserNames(usedNames);
          
          System.out.print("Possible user names are => ");
          username.printPossiableNames();
          
          break;

        case 9:
          System.out.println("Enter number of rows and columns for plot 2D array");
          int rows = sc.nextInt();
          int columns = sc.nextInt();
          int [][] plot = new int[rows][columns];
        
          System.out.println("Enter number crops row by row ");

          for (int i = 0; i < rows; i++){
            for (int j = 0; j < columns; j++){
              int crop = sc.nextInt();
              plot[i][j] = crop;
            }
          }

          FRQ8 farm = new FRQ8();
          // System.out.println("The Highest yield => " + farm.getHighestYield());

          break;

        case 10:
          ArrayList<FRQ9> myLibrary = new ArrayList<FRQ9>();
          
          FRQ9 book1 = new FRQ9("Frankenstein", "Mary Shelley");
          PictureBook book2 =new PictureBook("The Wonderful Wizard of Oz", " L. Frank Baum", "W.W. Denslow");

          myLibrary.add(book1);
          myLibrary.add(book2);

          System.out.println("My book Library Info ==> ");
          for(FRQ9 book : myLibrary){
            book.printBookInfo();
          }

          // Build booklisting
          
          ArrayList<BookListing> myBookListings = new ArrayList<BookListing>();

          BookListing bookListing1 = new BookListing(book1, 10.99);
          BookListing bookListing2 = new BookListing(book2, 12.99);

          myBookListings.add(bookListing1);
          myBookListings.add(bookListing2);

          System.out.println("My Book Library Info with $ value ==>");
          for(BookListing bl : myBookListings){
              bl.printDescription();
          }
        break;

        case 11:
          System.out.println("Enter numerator and denominator as positive integers one by one ");
          int a = sc.nextInt();
          sc.nextLine(); // to read new line after int
          int b = sc.nextInt();
          sc.nextLine(); // to read new line after int
          System.out.println("GCF ==> " + FRQ10.gcf(a,b) );
          FRQ10.reduceFraction(a,b);

        break;

        default:
          System.out.println(" ");
          break; 
      }
      sc.close();
    
      main(null);


  }
    
  
}

