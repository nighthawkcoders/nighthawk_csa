public class FRQ3two {
  private int width;
  private int height;

  public FRQ3two(int x, int y){
        this.width = x;
        this.height = y;
    }

  
}