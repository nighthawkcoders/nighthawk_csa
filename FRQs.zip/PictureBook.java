// import FRQ9;

public class PictureBook extends FRQ9{
    private String illustrator;
    
    public PictureBook(String title, String author, String illustrator){
      super(title, author);
      this.illustrator = illustrator;
    }

    public void printBookInfo(){
      System.out.println( super.toString() + " and illustrated by " + illustrator);
    }

    public String toString(){
      return super.toString() + " and illustrated by " + illustrator ;
    }
  }