import java.util.Random;

public class FRQ5Two {
  private static int pwdCount = 0;
  private int length;
  private String prefix;

  public FRQ5Two(int length, String prefix){
    this.length = length;
    this.prefix = prefix;
  }

  public FRQ5Two(int length){
    this.length = length;
    this.prefix = "A";
  }

  public static int pwdCount(){

    return pwdCount;
  }

  public String pwdGen(){
    int m = (int) Math.pow(10, length - 1);
    int genlength = m + new Random().nextInt(9 * m);
    pwdCount++;
    return prefix + "." + genlength;
    
  }

  


}