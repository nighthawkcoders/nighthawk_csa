public class FRQ4One {
  private char letter;
  private int count;

  public FRQ4One(){
    this.count = 0;
  }
  public void longestStreak(String str){
    if(str.length() == 1)
      return;

    char prvLetter = str.charAt(0);
    int currentCount = 1;
   
    for(int i=1 ; i<str.length(); i++){
      if(prvLetter==str.charAt(i)){
        currentCount++;
      }else{
        if(count < currentCount){
          letter = prvLetter;
          count = currentCount;
        }
        // need to reset current values
        prvLetter = str.charAt(i);
        currentCount = 1;
      }
    }
  }  
  public void printInfo(){
    System.out.println("LongestStreak ==> " + letter + " " + count);
  }
}