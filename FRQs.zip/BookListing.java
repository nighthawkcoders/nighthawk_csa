
public class BookListing{

  private FRQ9 book;
  private double value;

  public BookListing(FRQ9 book, double value){

    this.book = book;
    this.value = value;
  }
  public void printDescription(){
    System.out.println( book.toString() + ", $" + value);
  }
}